@echo off
:: 1. Set the Permanent System Variable
setx KANO_HOME "C:\.kanoprofile" /M

:: 2. Create the folder if it doesn't exist
if not exist "C:\.kanoprofile" (
    mkdir "C:\.kanoprofile"
    echo Created Kano Profile folder at C:\.kanoprofile
)

:: 3. Create subfolders for your specific apps
mkdir "C:\.kanoprofile\story"
mkdir "C:\.kanoprofile\art"
mkdir "C:\.kanoprofile\pong"

echo.
echo Kano Environment is ready! Please restart your PC or Log Off for changes to take effect.
pause